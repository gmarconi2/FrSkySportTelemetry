# Changelog

## [1.0.0] - 2025-04-25
- Prima versione stabile del progetto.
- Ricezione dati di telemetria tramite protocollo FrSky SmartPort (S.Port).
- Supporto sia a display LCD I2C 16x2 che OLED SSD1306/SH1106 128x64 I2C.
- Compatibilità con moduli XJT o Multi-Moduli tipo IRangeX IRX4 PLUS.
- Implementato corretto aggiornamento display ogni secondo.
- Visualizzazione dinamica dei dati base: RSSI, SWR, RxBatt.
- Gestione perdita di segnale (NO SIGNAL dopo 6 secondi).
- Ottimizzazione memoria per funzionare su Arduino UNO/NANO.
- Adattamento per utilizzo minimo della RAM (page buffer su OLED).

**Autori:**
- Basato su codice originale (c) Pawelsky.
- Adattamenti e ottimizzazione (c) Giampiero & Blade Runner (ChatGPT).
